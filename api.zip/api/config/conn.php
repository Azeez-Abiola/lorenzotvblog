<?php


$conn = mysqli_connect("localhost","root","","lorenzo");

define("API_KEY", "b15d41e6c3a4f5lorenzotv3a0b7a3a2");

if(!$conn){
     mysqli_connect_error();
}

?>
